
function [ranked] = GOR (SUvalues)
    len = size(SUvalues,1);
    maxval = max(max(SUvalues));
    %---------------avoid zero-element in proccessing
    for i=1:len
        SUvalues(i,1:i)=1000;
    end
    SUvaluesOrig = SUvalues;
    %---------------- Find the first non-relevant pairs
    [v,indcol] = min(SUvalues,[],2);
    [minval,rowmin] = min(v);
    colmin = indcol(rowmin);
    %--------------
    %initialization
    in=1;
    validwrite = zeros(len+1,1);
    ranked=[];
    for i =1:15*len
       if (in > len+1)
           break;
       end
       flag=1; i;
       if validwrite(rowmin)==0
            ranked(in) = rowmin; in=in+1;
            validwrite(rowmin) =1;
       end
       if(validwrite(colmin)==0)
            ranked(in) = colmin; in=in+1;
            validwrite(colmin) =1;
       end
       flagmin = SUvalues(rowmin,colmin);
       SUvalues(rowmin,colmin) = 100;
       rowmintemp = rowmin;
       colmintemp = colmin;
       mintemp = 100;
       iterate=0;
       while(flag == 1)
            if iterate > (len*2 +1)

                 for k=1:len 
                     if k==rowmintemp
                         continue;
                     end
                     if (SUvalues(k,colmintemp) < mintemp) && (SUvalues(k,colmintemp) ~= flagmin)
                      mintemp = SUvalues(k,colmintemp);
                      rowminN = k;colminN=colmintemp;
                     end
                 end

                for k=1:len+1 
                      if k==colmintemp
                         continue;
                     end
                     if(SUvalues(rowmintemp,k) < mintemp && SUvalues(rowmintemp,k)~=flagmin)
                      mintemp = SUvalues(rowmintemp,k);
                      colminN = k;rowminN=rowmintemp;
                     end
                end
                break; % break from while loop

            end %if iterate
            rowminN = rowmin;rowT=0;
            colminN = colmin;colT=0;
            minval = 100;
             for k=1:len 
                 if k==rowmin
                     continue;
                 end
                 if (SUvalues(k,colmin) < minval) && (SUvalues(k,colmin) ~= flagmin)
                  minval = SUvalues(k,colmin);
                  rowminN = k;colT=1;
                 end
             end

              for k=1:len+1 
                  if k==colmin
                     continue;
                 end
                 if(SUvalues(rowmin,k) < minval && SUvalues(rowmin,k)~=flagmin)
                  minval = SUvalues(rowmin,k);
                  colminN = k;rowT=1;colT=0;rowminN=rowmin;
                 end
              end
          %----------------------------------------
              if (colT==1) %next min was in column
                  AA=find(SUvaluesOrig(rowmin,:)< maxval+0.5);                             
                  avg =sum(SUvaluesOrig(rowmin,AA))/(size(AA,2));
                 if(minval <= avg)
                    flag = 0; continue;
                 end
                 iterate = iterate + 1;
                 flagmin = SUvalues(rowminN,colmin);
              end
              if (rowT==1) %next min was in row
                 AA=find(SUvaluesOrig(:,colmin) < maxval+0.5);                             
                 avg = sum(SUvaluesOrig(AA,colmin))/(size(AA,1));
                 if (minval <= avg)
                    flag = 0; continue;
                 end
                 iterate = iterate + 1;
                 flagmin = SUvalues(rowmin,colminN);
             end
       end %while
        rowmin = rowminN; 
        colmin = colminN; 
    end%for
%     clear SUvalues;
%     clear SUvaluesOrig;
  end