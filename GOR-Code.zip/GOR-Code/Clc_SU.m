%--- This function calculate releavancy meature between two features
%---input is a n by k data set which n is the number of samples
%---out put is a k by k matrix
function [ONR]= Clc_SU (Data)
    k = size(Data,2);
    SU = zeros(k-1,k);
    for i=1:k-1
        en1 = calentropy(Data(:,i)');
        
        for j=i+1:k
            en2 = calentropy(Data(:,j)');
%             mse_val = your_regression(Data(:,i),Data(:,j);
            SU(i,j) = (en2-calcondentropy(Data(:,j)',Data(:,i)') )/(en1+en2);
        end
    end
    %---Find ONR
    ONR = SU.* (mean(SU,2)* mean(SU,1));
end