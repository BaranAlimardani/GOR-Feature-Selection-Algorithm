﻿%---------------this package uses the GOR algorithm in [1] to reduce the
%---------------number of features in a Data set 
%----------------input:
%----------------    Data set n*k:
%---------------      n: the number of samples
%---------------      k: the number of features
%---------------output:
%---------------      ordered vector of features according to GOR algorithm
%-- [1] F. Alimardani .et.al,  Presenting a new search strategy to select synchronization values for classifying bipolar mood disorders from schizophrenic patients�,
%------ Engineering Applications of Artificial Intelligence, Vol. 26, Issue 2, pp. 913�923, 2013
function ranked_features=demoGOR()
    Data = load('sonar.dat.in');
    Data = Data(:,2:end);
    ONR = Clc_SU (Data);
    ranked_features = GOR(ONR);
    disp('Feature Ranking is done');
end


    





